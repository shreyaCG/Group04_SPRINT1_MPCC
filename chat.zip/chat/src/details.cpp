#include<details.h>
